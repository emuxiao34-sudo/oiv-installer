# OIV / ZIP Mod Installer (Android)

Installs `.oiv` and plain `.zip` mods into a game's `mods` folder, with one-tap undo.

## Build the APK
1. Install Android Studio (on a PC) and open this folder (`OivInstaller`).
2. Let Gradle sync (it downloads what it needs).
3. Build > Build APK(s). The APK appears in `app/build/outputs/apk/debug/`.
4. Copy it to your phone and install it.

## Use
1. Open the app and tap "Grant storage access" (All files access).
2. Set "Game mods folder" to the path of the port's `mods` folder.
3. Tap "Choose .oiv or .zip and install" and pick the mod.
4. Use "Undo" to restore the original files or remove added ones.

## How it works
- `.oiv`: reads `assembly.xml`. For each `<add>` / `<replace>` it copies the file from the
  package's `content/` folder to `<mods>/<archive path>/<target path>`, mirroring how OpenIV
  uses a `mods` folder (the `.rpf` is treated as a folder).
- `.zip` without `assembly.xml`: extracts files into the mods folder keeping their paths
  (a leading `mods/` in the zip is stripped).
- Every overwritten file is backed up first; files that did not exist are removed on undo.

## Limits
- Not supported (reported as "skipped" in the app): `<delete>` and text/XML edit operations
  (`<text>`, `<xml>`, etc.). Some graphics mods use these for settings files.
- The mods folder must be outside `Android/data` and `Android/obb`. Android 13+ blocks apps from
  those folders, so if the port's mods folder lives there this app cannot write to it.
- Only the zip-based OIV format is handled. The app never opens or edits `.rpf` archives.
- Untested: this was written without being compiled or run. If the build or a mod fails,
  send the error message or the skipped list.
