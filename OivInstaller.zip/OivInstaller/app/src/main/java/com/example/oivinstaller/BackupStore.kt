package com.example.oivinstaller

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupInfo(val id: String, val name: String, val time: String, val modsPath: String)

/**
 * One backup per install. Layout:
 *   filesDir/backups/<id>/manifest.json
 *   filesDir/backups/<id>/files/<relative path>   (originals that the install overwrote)
 * Files the install created from scratch are listed in the manifest and deleted on restore.
 */
class BackupStore(context: Context) {
    private val root = File(context.filesDir, "backups").apply { mkdirs() }

    class Session(
        val id: String,
        val name: String,
        val modsDir: File,
        val dir: File,
    ) {
        val created = mutableListOf<String>()
        val replaced = mutableListOf<String>()
        val filesDir = File(dir, "files")

        /** Call before writing [rel]; remembers whether it existed and saves the original. */
        fun beforeWrite(rel: String, target: File) {
            if (rel in created || rel in replaced) return
            if (target.exists()) {
                val saved = File(filesDir, rel)
                saved.parentFile?.mkdirs()
                target.copyTo(saved, overwrite = true)
                replaced += rel
            } else {
                created += rel
            }
        }

        fun commit() {
            val json = JSONObject()
                .put("name", name)
                .put("time", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()))
                .put("mods", modsDir.absolutePath)
                .put("created", JSONArray(created))
                .put("replaced", JSONArray(replaced))
            File(dir, "manifest.json").writeText(json.toString())
        }
    }

    fun begin(name: String, modsDir: File): Session {
        val id = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val dir = File(root, id).apply { mkdirs() }
        return Session(id, name, modsDir, dir)
    }

    fun list(): List<BackupInfo> =
        (root.listFiles() ?: emptyArray())
            .filter { File(it, "manifest.json").exists() }
            .sortedByDescending { it.name }
            .mapNotNull {
                runCatching {
                    val j = JSONObject(File(it, "manifest.json").readText())
                    BackupInfo(it.name, j.getString("name"), j.getString("time"), j.getString("mods"))
                }.getOrNull()
            }

    /** Puts the mods folder back the way it was before this install. Returns a short summary. */
    fun restore(id: String): String {
        val dir = File(root, id)
        val j = JSONObject(File(dir, "manifest.json").readText())
        val modsDir = File(j.getString("mods"))
        var restored = 0
        var removed = 0

        val replaced = j.getJSONArray("replaced")
        for (i in 0 until replaced.length()) {
            val rel = replaced.getString(i)
            val saved = File(dir, "files/$rel")
            if (saved.exists()) {
                val target = File(modsDir, rel)
                target.parentFile?.mkdirs()
                saved.copyTo(target, overwrite = true)
                restored++
            }
        }
        val created = j.getJSONArray("created")
        for (i in 0 until created.length()) {
            val target = File(modsDir, created.getString(i))
            if (target.delete()) removed++
            var parent = target.parentFile
            while (parent != null && parent != modsDir && parent.list()?.isEmpty() == true) {
                parent.delete()
                parent = parent.parentFile
            }
        }
        dir.deleteRecursively()
        return "Restored $restored file(s), removed $removed added file(s)."
    }
}
