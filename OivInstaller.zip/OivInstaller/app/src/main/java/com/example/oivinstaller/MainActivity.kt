package com.example.oivinstaller

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val resumeTick = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App(resumeTick.intValue) } }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}

private fun hasStorageAccess(ctx: android.content.Context): Boolean =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
        PackageManager.PERMISSION_GRANTED

private fun displayNameOf(ctx: android.content.Context, uri: Uri): String =
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && c.moveToFirst()) c.getString(i) else null
    } ?: "mod"

@Composable
private fun App(resumeTick: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("settings", 0) }

    var modsPath by remember { mutableStateOf(prefs.getString("mods", "/storage/emulated/0/GTAV/mods") ?: "") }
    var log by remember { mutableStateOf("Pick a .oiv or .zip to install.") }
    var busy by remember { mutableStateOf(false) }
    var backups by remember { mutableStateOf(BackupStore(ctx).list()) }
    val hasAccess = remember(resumeTick) { hasStorageAccess(ctx) }

    val legacyPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val modsDir = File(modsPath.trim())
        scope.launch {
            busy = true
            log = "Installing…"
            log = try {
                val name = displayNameOf(ctx, uri)
                val r = withContext(Dispatchers.IO) {
                    modsDir.mkdirs()
                    if (!modsDir.isDirectory || !modsDir.canWrite()) {
                        error("Can't write to ${modsDir.path}. Check the path and storage access.")
                    }
                    OivInstaller.install(ctx, uri, name, modsDir)
                }
                buildString {
                    append("Installed \"${r.name}\": ${r.installed} file(s) written.")
                    if (r.skipped.isNotEmpty()) {
                        append("\n\nSkipped ${r.skipped.size}:\n")
                        append(r.skipped.take(20).joinToString("\n") { "• $it" })
                        if (r.skipped.size > 20) append("\n…and ${r.skipped.size - 20} more")
                    }
                }
            } catch (e: Exception) {
                "Failed: ${e.message}"
            }
            backups = BackupStore(ctx).list()
            busy = false
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("OIV / ZIP Mod Installer", style = MaterialTheme.typography.headlineSmall)

        if (!hasAccess) {
            Text("Storage access is needed to write into the game's mods folder.")
            Button(onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:${ctx.packageName}"),
                        ),
                    )
                } else {
                    legacyPerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }) { Text("Grant storage access") }
        }

        OutlinedTextField(
            value = modsPath,
            onValueChange = {
                modsPath = it
                prefs.edit().putString("mods", it).apply()
            },
            label = { Text("Game mods folder") },
            modifier = Modifier.fillMaxWidth(),
        )

        Button(
            onClick = { picker.launch(arrayOf("*/*")) },
            enabled = hasAccess && !busy && modsPath.isNotBlank(),
            modifier = Modifier.fillMaxWidth(),
        ) { Text("Choose .oiv or .zip and install") }

        Text(log)

        HorizontalDivider()
        Text("Undo", style = MaterialTheme.typography.titleMedium)
        if (backups.isEmpty()) Text("No installs to undo yet.")
        backups.forEach { b ->
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Column(Modifier.weight(1f)) {
                    Text(b.name)
                    Text(b.time, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedButton(
                    enabled = !busy,
                    onClick = {
                        scope.launch {
                            busy = true
                            log = try {
                                withContext(Dispatchers.IO) { BackupStore(ctx).restore(b.id) }
                            } catch (e: Exception) {
                                "Restore failed: ${e.message}"
                            }
                            backups = BackupStore(ctx).list()
                            busy = false
                        }
                    },
                ) { Text("Undo") }
            }
        }
    }
}
