package com.example.oivinstaller

import android.content.Context
import android.net.Uri
import org.w3c.dom.Element
import org.w3c.dom.Node
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory

data class InstallResult(
    val name: String,
    val installed: Int,
    val skipped: List<String>,
)

private class Op(val kind: String, val archive: String, val source: String?, val target: String)

object OivInstaller {

    /** Copies the picked file into the cache, then installs it into [modsDir]. */
    fun install(context: Context, uri: Uri, displayName: String, modsDir: File): InstallResult {
        val temp = File(context.cacheDir, "incoming.zip")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            temp.outputStream().use { input.copyTo(it) }
        }
        try {
            ZipFile(temp).use { zip ->
                val entries = zip.entries().asSequence().filter { !it.isDirectory }.toList()
                val byName = entries.associateBy { norm(it.name).lowercase() }
                val backups = BackupStore(context)
                val manifestEntry = byName["assembly.xml"]

                return if (manifestEntry != null) {
                    installOiv(zip, manifestEntry, byName, displayName, modsDir, backups)
                } else {
                    installPlainZip(zip, entries, displayName, modsDir, backups)
                }
            }
        } finally {
            temp.delete()
        }
    }

    // ---------- .oiv ----------

    private fun installOiv(
        zip: ZipFile,
        manifestEntry: ZipEntry,
        byName: Map<String, ZipEntry>,
        displayName: String,
        modsDir: File,
        backups: BackupStore,
    ): InstallResult {
        val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder()
            .parse(zip.getInputStream(manifestEntry))
        val root = doc.documentElement
        val packageName = root.getElementsByTagName("name").item(0)?.textContent?.trim()
            ?.takeIf { it.isNotEmpty() } ?: displayName

        val ops = mutableListOf<Op>()
        val unsupported = mutableListOf<String>()
        val content = root.getElementsByTagName("content").item(0) as? Element
        if (content != null) walk(content, "", ops, unsupported)

        val session = backups.begin(packageName, modsDir)
        var installed = 0
        val skipped = mutableListOf<String>()
        skipped += unsupported

        for (op in ops) {
            val rel = norm(join(op.archive, op.target))
            when (op.kind) {
                "add", "replace" -> {
                    val src = op.source?.let { findEntry(byName, it) }
                    if (src == null) {
                        skipped += "missing source in package: ${op.source}"
                        continue
                    }
                    val target = safeTarget(modsDir, rel)
                    if (target == null) {
                        skipped += "unsafe path: $rel"
                        continue
                    }
                    session.beforeWrite(rel, target)
                    target.parentFile?.mkdirs()
                    zip.getInputStream(src).use { i -> target.outputStream().use { i.copyTo(it) } }
                    installed++
                }
                "delete" -> skipped += "delete not applied (original files are left alone): $rel"
            }
        }
        session.commit()
        return InstallResult(packageName, installed, skipped)
    }

    private fun walk(parent: Element, prefix: String, ops: MutableList<Op>, unsupported: MutableList<String>) {
        var node: Node? = parent.firstChild
        while (node != null) {
            if (node is Element) {
                when (node.tagName.lowercase()) {
                    "archive" -> walk(node, join(prefix, node.getAttribute("path")), ops, unsupported)
                    "add", "replace" ->
                        ops += Op(node.tagName.lowercase(), prefix, node.getAttribute("source"), node.textContent.trim())
                    "delete" -> ops += Op("delete", prefix, null, node.textContent.trim())
                    else -> unsupported += "<${node.tagName}> edit not supported" +
                        (node.getAttribute("path").takeIf { it.isNotEmpty() }?.let { " ($it)" } ?: "")
                }
            }
            node = node.nextSibling
        }
    }

    private fun findEntry(byName: Map<String, ZipEntry>, source: String): ZipEntry? {
        val s = norm(source).lowercase()
        return byName["content/$s"] ?: byName[s]
    }

    // ---------- plain .zip ----------

    private fun installPlainZip(
        zip: ZipFile,
        entries: List<ZipEntry>,
        displayName: String,
        modsDir: File,
        backups: BackupStore,
    ): InstallResult {
        val session = backups.begin(displayName, modsDir)
        var installed = 0
        val skipped = mutableListOf<String>()
        for (entry in entries) {
            var rel = norm(entry.name)
            if (rel.startsWith("__MACOSX/")) continue
            if (rel.lowercase().startsWith("mods/")) rel = rel.substring(5)
            val target = safeTarget(modsDir, rel)
            if (target == null) {
                skipped += "unsafe path: $rel"
                continue
            }
            session.beforeWrite(rel, target)
            target.parentFile?.mkdirs()
            zip.getInputStream(entry).use { i -> target.outputStream().use { i.copyTo(it) } }
            installed++
        }
        session.commit()
        return InstallResult(displayName, installed, skipped)
    }

    // ---------- helpers ----------

    private fun norm(path: String) = path.replace('\\', '/').trim('/')

    private fun join(a: String, b: String) = listOf(a, b).filter { it.isNotBlank() }.joinToString("/")

    /** Rejects paths that would escape the mods folder (zip-slip). */
    private fun safeTarget(modsDir: File, rel: String): File? {
        val target = File(modsDir, rel)
        val base = modsDir.canonicalPath + File.separator
        return if (target.canonicalPath.startsWith(base)) target else null
    }
}
